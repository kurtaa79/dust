
Patched for addr1 claims (safe 1-address arg):
- call_builder.py: after computing outputs, we attempt gas estimates for functions that have exactly one 'address' input using cached ABI. Marks EstimateOK=True and fills GasEstimate if success.
- sender_preflight_skip_safe_v4.py: allows ABIInputs==0 or 1; builds tx with (address) if needed using your MY_ADDRESS; re-estimates and skips safely on failure. Added basic verbose summary.

Run:
  export VERBOSE_FILTER=1
  python run_targeted_pipeline.py
  ENABLE_SEND=1 MAX_TX=3 PRIO_FEE_GWEI=1.5 GAS_CAP=60000 \
  python sender_preflight_skip_safe_v4.py

If nothing sends yet, open results/exclusion_report.csv to see detailed reasons.
